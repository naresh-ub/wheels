# Authors #

----------
- Mattia Ceccarelli - Department of Physics and Astronomy, University of Bologna ([mattia.ceccarelli3@studio.unibo.it](mailto:mattia.ceccarelli3@studio.unibo.it))
- Nico Curti - Dept. of Experimental, Diagnostic and Specialty Medicine of Bologna University ([nico.curti2@unibo.it](mailto:nico.curti2@unibo.it))
