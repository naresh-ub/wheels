#!/usr/bin/env python
# -*- coding: utf-8 -*-

__author__  = ['Mattia Ceccarelli', 'Nico Curti']
__email__ = ['mattia.ceccarelli3@studio.unibo.it', 'nico.curti2@unibo.it']

# update this numbers after important commits/editing or updates of the modules
VERSION = (1, 0, 0)

__version__ = '.'.join(map(str, VERSION))
